package com.example.trabalhosub.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.trabalhosub.helper.SQLiteDataHelper;
import com.example.trabalhosub.model.Paises;

import java.util.ArrayList;

public class PaisesDao implements GenericDao<Paises>{

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase baseDados;

    private String[]colunas = {"CODIGO", "DESCRICAO"};
    private String tabela = "PAISES";
    private Context context;

    private static PaisesDao instancia;

    public static PaisesDao getInstancia(Context context){
        if(instancia == null){
            return instancia = new PaisesDao(context);
        }else{
            return instancia;
        }
    }

    private PaisesDao(Context context){
        this.context = context;

        //Abrir a conexão com a base de dados
        openHelper = new SQLiteDataHelper(this.context,
                "DBPAISES", null, 1);

        //instanciando a base de dados
        baseDados = openHelper.getWritableDatabase();


    }

    public long insert(Paises obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getCodigo());
            valores.put(colunas[1], obj.getDescricao());

            return baseDados.insert(tabela, null, valores);

        }catch (SQLException ex){
            Log.e("UNIPAR", "ERRO: PaisesDao.insert() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Paises obj) {
        return 0;
    }

    public long delete(Paises obj) {
        try{
            String[]identificador = {String.valueOf(obj.getCodigo())};

            return baseDados.delete(tabela,
                    colunas[0]+"= ?", identificador);
        }catch (SQLException ex){
            Log.e("UNIPAR", "ERRO: VendasDao.delete() "+ex.getMessage());
        }
        return 0;
    }

    public ArrayList<Paises> getAll() {
        ArrayList<Paises> lista = new ArrayList<>();
        try{
            Cursor cursor = baseDados.query(tabela,
                    colunas, null,
                    null, null,
                    null, colunas[0]+" desc");

            if(cursor.moveToFirst()){
                do{
                    Paises paises = new Paises();
                    paises.setCodigo(cursor.getInt(0));
                    paises.setDescricao(cursor.getString(1));


                    lista.add(paises);

                }while (cursor.moveToNext());
            }

        }catch (SQLException ex){
            Log.e("UNIPAR", "ERRO: PaisesDao.getAll() "+ex.getMessage());
        }

        return lista;
    }

    @Override
    public Paises getById(int id) {
        return null;
    }

}
