package com.example.trabalhosub.controller;

import android.content.Context;
import android.widget.TextView;

import com.example.trabalhosub.dto.PaisesDTO;
import com.example.trabalhosub.retrofit.RetrofitConfig;


import com.example.trabalhosub.dao.PaisesDao;
import com.example.trabalhosub.model.Paises;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PaisesController {
    private static Context context;

    public static void getViaPais(Context context) {
        try {
            retrofit2.Call<ArrayList<PaisesDTO>> call = new RetrofitConfig().paisesService().getPaises();
            call.enqueue(new Callback<ArrayList<PaisesDTO>>() {
                @Override
                public void onResponse(Call<ArrayList<PaisesDTO>> call, Response<ArrayList<PaisesDTO>> response) {
                    ArrayList<PaisesDTO> listaPais = response.body();
                    for (int i = 0; i < listaPais.size(); i++) {
                        PaisesDTO pais = listaPais.get(i);

                        salvar(pais.getCodigo(), pais.getDescricao(), context);
                    }
                }

                @Override
                public void onFailure(Call<ArrayList<PaisesDTO>> call, Throwable t) {
                }
            });
        } catch (Exception ex) {
        }
    }

    public static String salvar(int codigo, String descricao, Context context) {
        try {
            Paises pais = new Paises();

            pais.setCodigo(codigo);
            pais.setDescricao(descricao);

            PaisesDao.getInstancia(context).insert(pais);
        } catch (Exception ex) {
            return "Erro ao gravar pais." + ex.getMessage();
        }
        return null;
    }

    public static ArrayList<Paises> retornar(Context context) {
        return PaisesDao.getInstancia(context).getAll();
    }
}