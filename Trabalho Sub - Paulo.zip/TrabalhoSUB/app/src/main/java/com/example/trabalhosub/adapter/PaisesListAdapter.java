package com.example.trabalhosub.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.trabalhosub.R;
import com.example.trabalhosub.model.Paises;

import android.view.ViewGroup;

import java.util.ArrayList;


public class PaisesListAdapter extends RecyclerView.Adapter<PaisesListAdapter.ViewHolder>{

        private ArrayList<Paises> listaPaises;
        private Context context;

        public PaisesListAdapter(ArrayList<Paises> listaPaises, Context context) {
            this.listaPaises = listaPaises;
            this.context = context;
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            View listView = inflater.inflate(R.layout.item_list_paises,
                    parent, false);

            return new ViewHolder(listView);
        }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Paises paisSelecionado = listaPaises.get(position);
            holder.tvCodigo.setText(String.valueOf(paisSelecionado.getCodigo()));
            holder.tvDescricao.setText(paisSelecionado.getDescricao());
        }

    @Override
    public int getItemCount() {
        return this.listaPaises.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
            public TextView tvCodigo;

            public TextView tvDescricao;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                this.tvCodigo = itemView.findViewById(R.id.tvCodigo);
                this.tvDescricao = itemView.findViewById(R.id.tvDescricao);
            }
        }
    }


