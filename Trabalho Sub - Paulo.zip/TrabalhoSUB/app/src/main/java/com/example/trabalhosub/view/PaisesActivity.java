package com.example.trabalhosub.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import com.example.trabalhosub.adapter.PaisesListAdapter;
import com.example.trabalhosub.R;
import com.example.trabalhosub.controller.PaisesController;
import com.example.trabalhosub.model.Paises;

import java.util.ArrayList;

public class PaisesActivity extends AppCompatActivity {

    private RecyclerView rvPaises;
    private PaisesController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paises);

        rvPaises = findViewById(R.id.rvPaises);

        carregarlistapaises();
    }

    private void carregarlistapaises() {
        ArrayList<Paises>listaPais = controller.retornar(this);
        PaisesListAdapter adapter = new PaisesListAdapter(listaPais,this);
        rvPaises.setLayoutManager(new LinearLayoutManager(this));
        rvPaises.setAdapter(adapter);
    }
}