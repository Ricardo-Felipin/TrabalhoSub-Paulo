package com.example.trabalhosub;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import com.example.trabalhosub.controller.PaisesController;
import com.example.trabalhosub.view.PaisesActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btSincronizar = findViewById(R.id.btSincronizar);
        Button btMostrarPaises = findViewById(R.id.btMostrarPaises);

        btSincronizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PaisesController.getViaPais(MainActivity.this);
            }
        });

        btMostrarPaises.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PaisesActivity.class);
                startActivity(intent);
            }
        });
    }

}

